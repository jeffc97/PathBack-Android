# PathBack for Android

PathBack is an original, accessibility-first alpha indoor route recorder inspired by the
general purpose of Clew. It records a trail using ARCore motion tracking and guides
the user along that trail in either direction.

## Open and build

1. Open this folder in Android Studio.
2. Allow Android Studio to install the requested Android SDK and sync Gradle.
3. Connect an ARCore-supported Android phone (the Pixel 9 is supported).
4. Build and run the `app` configuration.

The app requests camera permission because ARCore uses the camera to estimate the
phone's movement. Route data stays on the phone. No images or video are saved.

## Accessible use

Hold the phone upright with the rear camera unobstructed. From the home screen,
activate **Record a new route**. Wait for “Tracking ready,” then activate **Start
recording**. Walk normally. Add named landmarks if desired. At the destination,
activate **Finish and save**, enter a route name, and save it. Choose the route and
select **Guide forward** or **Guide back**.

Guidance announces clock directions and distance. A short vibration means continue;
two pulses mean turn; three pulses indicate that tracking is limited or the user is
off the recorded path.

## Important safety limits

This is an orientation aid, not a mobility aid. It does not detect drop-offs,
traffic, stairs, doors, or every obstacle. Continue using a cane or guide dog and
your normal travel skills. ARCore tracking can drift, especially in darkness,
featureless hallways, reflective spaces, or when the camera is covered.

## Offline local relocalization

PathBack uses a high-contrast local start marker to re-establish the same coordinate
system when a saved route is reopened. Print the marker shown on the recording screen
at 18 centimeters square and secure it flat at the starting point. Scan it before
recording and again before guidance. Marker recognition and route processing occur
on the phone; no map, image, or video is uploaded. The marker is the practical offline
alternative to a cloud-hosted visual anchor. This release remains an engineering
preview until tested in the specific buildings where it will be used.
