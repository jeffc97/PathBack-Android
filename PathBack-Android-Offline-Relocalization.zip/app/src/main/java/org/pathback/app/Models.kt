package org.pathback.app

import kotlinx.serialization.Serializable
import kotlin.math.*

@Serializable data class Point3(val x: Float, val y: Float, val z: Float, val time: Long)
@Serializable data class Landmark(val name: String, val pointIndex: Int)
@Serializable data class SavedRoute(
    val id: String, val name: String, val created: Long,
    val points: List<Point3>, val landmarks: List<Landmark> = emptyList()
)

data class Guidance(val pointIndex: Int, val meters: Float, val clock: Int, val offRoute: Boolean)

object Navigator {
    fun distance(a: Point3, b: Point3) = sqrt((a.x-b.x).pow(2)+(a.y-b.y).pow(2)+(a.z-b.z).pow(2))
    fun guidance(position: Point3, yaw: Float, points: List<Point3>, from: Int): Guidance? {
        if (points.isEmpty()) return null
        val lo = (from - 8).coerceAtLeast(0)
        val hi = (from + 20).coerceAtMost(points.lastIndex)
        val nearest = (lo..hi).minByOrNull { distance(position, points[it]) } ?: return null
        val target = (nearest + 3).coerceAtMost(points.lastIndex)
        val p = points[target]
        val dx = p.x-position.x; val dz = p.z-position.z
        val bearing = atan2(dx, -dz)
        var relative = Math.toDegrees((bearing-yaw).toDouble()).toFloat()
        while (relative < -180) relative += 360
        while (relative > 180) relative -= 360
        val clock = ((relative / 30f).roundToInt() + 12).let { if (it <= 0) it+12 else if (it>12) it-12 else it }
        return Guidance(nearest, distance(position, p), clock, distance(position, points[nearest]) > 2.5f)
    }
}

