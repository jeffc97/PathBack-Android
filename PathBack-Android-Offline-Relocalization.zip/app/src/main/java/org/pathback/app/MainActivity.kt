package org.pathback.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.ar.core.exceptions.*
import java.text.DateFormat
import java.util.*
import kotlin.math.abs

enum class Screen { HOME, RECORD, ROUTE }

class MainActivity : ComponentActivity() {
    private lateinit var feedback: Feedback
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); feedback = Feedback(this)
        setContent { PathBackApp(feedback) }
    }
    override fun onDestroy() { feedback.close(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun PathBackApp(feedback: Feedback) {
    val context = LocalContext.current
    val store = remember { RouteStore(context) }
    var routes by remember { mutableStateOf(store.load()) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var selected by remember { mutableStateOf<SavedRoute?>(null) }
    var guidanceReverse by remember { mutableStateOf(false) }
    var cameraGranted by remember { mutableStateOf(context.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { cameraGranted = it }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF003B73))) {
        Scaffold(topBar = { TopAppBar(title = { Text("PathBack", fontSize = 26.sp) }, navigationIcon = {
            if (screen != Screen.HOME) TextButton(onClick = { screen = Screen.HOME }) { Text("Back") }
        }) }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (screen) {
                    Screen.HOME -> Home(routes, onRecord = {
                        if (!cameraGranted) permission.launch(Manifest.permission.CAMERA) else screen = Screen.RECORD
                    }, onRoute = { selected = it; screen = Screen.ROUTE })
                    Screen.RECORD -> if (cameraGranted) Recorder(feedback) { route ->
                        routes = routes + route; store.save(routes); selected = route; screen = Screen.ROUTE
                    } else PermissionMessage { permission.launch(Manifest.permission.CAMERA) }
                    Screen.ROUTE -> selected?.let { route -> RouteDetails(route, onGuide = { reverse ->
                        guidanceReverse = reverse; screen = Screen.ROUTE
                    }, guiding = guidanceReverse, feedback = feedback, cameraGranted = cameraGranted,
                        onDelete = { routes = routes - route; store.save(routes); screen = Screen.HOME }) }
                }
            }
        }
    }
}

@Composable private fun Home(routes: List<SavedRoute>, onRecord: () -> Unit, onRoute: (SavedRoute) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("Indoor route guidance", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.semantics { heading() }) }
        item { Text("Record a path, then receive spoken and vibration guidance in either direction.", fontSize = 18.sp) }
        item { BigButton("Record a new route", "Starts the camera-based indoor route recorder", onRecord) }
        item { Text("Saved routes", style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() }) }
        if (routes.isEmpty()) item { Text("No routes saved", fontSize = 18.sp) }
        items(routes) { r -> OutlinedButton(onClick = { onRoute(r) }, modifier = Modifier.fillMaxWidth().heightIn(min = 64.dp)) {
            Column { Text(r.name, fontSize = 20.sp); Text(DateFormat.getDateTimeInstance().format(Date(r.created))) }
        } }
        item { Text("Safety: Use your cane or guide dog. PathBack does not detect traffic, stairs, drop-offs, or all obstacles.", fontSize = 16.sp) }
    }
}

@Composable private fun PermissionMessage(request: () -> Unit) = Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
    Text("Camera permission is required for motion tracking. PathBack does not save pictures or video.", fontSize = 20.sp)
    BigButton("Allow camera", "Opens the Android camera permission request", request)
}

@Composable private fun Recorder(feedback: Feedback, onSaved: (SavedRoute) -> Unit) {
    val context = LocalContext.current
    var latest by remember { mutableStateOf<Point3?>(null) }; var tracking by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }; val points = remember { mutableStateListOf<Point3>() }
    val landmarks = remember { mutableStateListOf<Landmark>() }; var showSave by remember { mutableStateOf(false) }
    var routeName by remember { mutableStateOf("") }; var landmarkName by remember { mutableStateOf("") }; var showLandmark by remember { mutableStateOf(false) }
    var previousTracking by remember { mutableStateOf(false) }; var markerFound by remember { mutableStateOf(false) }
    val tracker = remember { ArTracker(context) { point, _, ok, marker -> latest = point; tracking = ok; markerFound = marker } }
    DisposableEffect(Unit) { runCatching { tracker.resume(context) }.onFailure { feedback.speak(arError(it), true) }; onDispose { tracker.pause(); tracker.close() } }
    LaunchedEffect(latest, recording) {
        val p = latest ?: return@LaunchedEffect
        if (tracking && !previousTracking) feedback.speak("Tracking ready", true)
        if (!tracking && previousTracking) { feedback.speak("Tracking limited. Hold the phone upright and move slowly.", true); feedback.pulse(3) }
        previousTracking = tracking
        if (recording && tracking && (points.isEmpty() || Navigator.distance(points.last(), p) >= .35f)) points += p
    }
    Box(Modifier.fillMaxSize()) {
        AndroidView({ tracker.view }, Modifier.fillMaxSize().semantics { invisibleToUser() })
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(if (tracking) "Start marker found. Tracking ready" else "Point the rear camera at the PathBack start marker", fontSize = 22.sp,
                modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
            Text(if (recording) "Recording. ${points.size} trail points." else "The marker must be printed at 18 centimeters square or shown at that size on another device. Hold the phone upright.", fontSize = 18.sp)
            if (!recording && !markerFound) Image(MarkerFactory.bitmap(500).asImageBitmap(), "PathBack start marker. Print this marker at 18 centimeters square.", Modifier.fillMaxWidth().weight(1f))
            if (!recording) BigButton("Start recording", "Begins recording your indoor path", enabled = tracking) { recording = true; feedback.speak("Recording started", true); feedback.pulse(1) }
            else {
                BigButton("Add landmark", "Adds a named place at your current position") { landmarkName = ""; showLandmark = true }
                BigButton("Finish and save", "Stops recording and asks for a route name", enabled = points.size > 3) { recording = false; showSave = true; feedback.speak("Recording stopped", true) }
            }
        }
    }
    if (showLandmark) NameDialog("Landmark name", landmarkName, { landmarkName = it }, { showLandmark = false }, {
        if (landmarkName.isNotBlank()) { landmarks += Landmark(landmarkName.trim(), points.lastIndex.coerceAtLeast(0)); feedback.speak("Landmark ${landmarkName.trim()} added") }; showLandmark = false
    })
    if (showSave) NameDialog("Route name", routeName, { routeName = it }, { showSave = false }, {
        if (routeName.isNotBlank()) onSaved(SavedRoute(UUID.randomUUID().toString(), routeName.trim(), System.currentTimeMillis(), points.toList(), landmarks.toList()))
    })
}

@Composable private fun RouteDetails(route: SavedRoute, onGuide: (Boolean) -> Unit, guiding: Boolean, feedback: Feedback, cameraGranted: Boolean, onDelete: () -> Unit) {
    var mode by remember(route.id) { mutableStateOf<Boolean?>(null) }
    if (mode != null && cameraGranted) { Guide(route, mode == true, feedback) { mode = null }; return }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(route.name, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.semantics { heading() })
        Text("${route.points.size} trail points. ${route.landmarks.size} landmarks.", fontSize = 18.sp)
        BigButton("Guide forward", "Guides from the original start to the destination") { mode = false; onGuide(false) }
        BigButton("Guide back", "Guides from the destination back to the original start") { mode = true; onGuide(true) }
        route.landmarks.forEach { Text("Landmark: ${it.name}", fontSize = 18.sp) }
        OutlinedButton(onClick = onDelete, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("Delete route") }
    }
}

@Composable private fun Guide(route: SavedRoute, reverse: Boolean, feedback: Feedback, stop: () -> Unit) {
    val context = LocalContext.current
    val points = remember(route.id, reverse) { if (reverse) route.points.reversed() else route.points }
    var position by remember { mutableStateOf<Point3?>(null) }; var yaw by remember { mutableFloatStateOf(0f) }; var tracking by remember { mutableStateOf(false) }
    var index by remember { mutableIntStateOf(0) }; var lastSpeech by remember { mutableLongStateOf(0) }; var status by remember { mutableStateOf("Finding your position…") }
    var markerFound by remember { mutableStateOf(false) }
    val tracker = remember { ArTracker(context) { p, y, ok, marker -> position = p; yaw = y; tracking = ok; markerFound = marker } }
    DisposableEffect(Unit) { runCatching { tracker.resume(context) }.onFailure { feedback.speak(arError(it), true) }; onDispose { tracker.pause(); tracker.close() } }
    LaunchedEffect(position) {
        val p = position ?: return@LaunchedEffect
        if (!markerFound) { status = "Point the rear camera at the PathBack start marker"; return@LaunchedEffect }
        if (!tracking) { status = "Tracking limited"; return@LaunchedEffect }
        val g = Navigator.guidance(p, yaw, points, index) ?: return@LaunchedEffect; index = g.pointIndex
        status = if (g.offRoute) "Off route. Move toward ${g.clock} o'clock." else "${g.meters.toInt().coerceAtLeast(1)} meters, ${g.clock} o'clock"
        val now = System.currentTimeMillis()
        if (now-lastSpeech > 4000) { feedback.speak(status, true); feedback.pulse(if (g.offRoute) 3 else if (g.clock in 11..12 || g.clock == 1) 1 else 2); lastSpeech = now }
        if (index >= points.lastIndex-3 && g.meters < 1.2f) { feedback.speak("You have arrived", true); feedback.pulse(3); stop() }
    }
    Box(Modifier.fillMaxSize()) {
        AndroidView({ tracker.view }, Modifier.fillMaxSize().semantics { invisibleToUser() })
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text("Guiding ${if (reverse) "back" else "forward"}", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.semantics { heading() })
            Text(status, fontSize = 24.sp, modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
            Text("Keep the phone upright. Continue using your cane or guide dog.", fontSize = 18.sp)
            BigButton("Repeat instruction", "Repeats the current navigation instruction") { feedback.speak(status, true) }
            BigButton("Stop guidance", "Ends navigation") { stop() }
        }
    }
}

@Composable private fun BigButton(text: String, description: String, enabled: Boolean = true, action: () -> Unit) {
    Button(onClick = action, enabled = enabled, modifier = Modifier.fillMaxWidth().heightIn(min = 68.dp).semantics { contentDescription = "$text. $description" }) { Text(text, fontSize = 20.sp) }
}

@Composable private fun NameDialog(title: String, value: String, change: (String) -> Unit, cancel: () -> Unit, save: () -> Unit) {
    AlertDialog(onDismissRequest = cancel, title = { Text(title) }, text = { OutlinedTextField(value, change, label = { Text(title) }, singleLine = true) },
        confirmButton = { TextButton(onClick = save, enabled = value.isNotBlank()) { Text("Save") } }, dismissButton = { TextButton(onClick = cancel) { Text("Cancel") } })
}

private fun arError(t: Throwable) = when (t) {
    is UnavailableArcoreNotInstalledException -> "Google Play Services for A R must be installed."
    is UnavailableApkTooOldException -> "Google Play Services for A R must be updated."
    is UnavailableDeviceNotCompatibleException -> "This phone does not support A R motion tracking."
    is CameraNotAvailableException -> "The camera is being used by another app."
    else -> "Motion tracking could not start. ${t.message ?: ""}"
}
