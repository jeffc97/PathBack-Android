package org.pathback.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import com.google.ar.core.*
import java.util.concurrent.atomic.AtomicReference
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class ArTracker(context: Context, private val onPose: (Point3, Float, Boolean, Boolean) -> Unit) : GLSurfaceView.Renderer {
    val view = GLSurfaceView(context).apply {
        setEGLContextClientVersion(2); setRenderer(this@ArTracker); renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
    }
    private val sessionRef = AtomicReference<Session?>()
    private var texture = 0
    private var markerPose: Pose? = null

    fun resume(context: Context) {
        if (sessionRef.get() == null) {
            val session = Session(context)
            val database = AugmentedImageDatabase(session).apply {
                addImage("pathback_start", MarkerFactory.bitmap(), 0.18f)
            }
            session.configure(Config(session).apply {
                focusMode = Config.FocusMode.AUTO
                augmentedImageDatabase = database
            })
            sessionRef.set(session)
        }
        sessionRef.get()?.resume(); view.onResume()
    }
    fun pause() { view.onPause(); sessionRef.get()?.pause() }
    fun close() { sessionRef.getAndSet(null)?.close() }
    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        val textures = IntArray(1); GLES20.glGenTextures(1, textures, 0); texture = textures[0]
        sessionRef.get()?.setCameraTextureName(texture)
        GLES20.glClearColor(0.97f, 0.97f, 0.97f, 1f)
    }
    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) { GLES20.glViewport(0, 0, width, height) }
    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        val session = sessionRef.get() ?: return
        if (texture != 0) session.setCameraTextureName(texture)
        runCatching {
            val frame = session.update()
            val camera = frame.camera
            frame.getUpdatedTrackables(AugmentedImage::class.java).firstOrNull {
                it.name == "pathback_start" && it.trackingState == TrackingState.TRACKING
            }?.let { image -> markerPose = image.centerPose }
            val localPose = markerPose?.inverse()?.compose(camera.pose)
            val pose = localPose ?: camera.pose
            val forward = pose.zAxis
            val yaw = kotlin.math.atan2(-forward[0], -forward[2])
            onPose(Point3(pose.tx(), pose.ty(), pose.tz(), System.currentTimeMillis()), yaw,
                camera.trackingState == TrackingState.TRACKING && markerPose != null, markerPose != null)
        }
    }
}

/** A deterministic, high-feature 18 cm marker. It is generated locally and never uploaded. */
object MarkerFactory {
    fun bitmap(size: Int = 800): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(b); c.drawColor(Color.WHITE)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE; p.strokeWidth = size * .045f; p.color = Color.BLACK
        c.drawRect(size*.04f, size*.04f, size*.96f, size*.96f, p)
        p.style = Paint.Style.FILL
        val grid = 10; val cell = size * .075f; val left = size*.125f; val top = size*.125f
        // Fixed asymmetric pattern with many corners for ARCore feature matching.
        val rows = intArrayOf(0b1110100111,0b1001010001,0b1011101101,0b1100010011,0b0010111010,
            0b1111000101,0b0100111110,0b1010010101,0b1101101011,0b1000111101)
        for (y in 0 until grid) for (x in 0 until grid) if ((rows[y] shr (grid-1-x) and 1) == 1)
            c.drawRect(left+x*cell, top+y*cell, left+(x+1)*cell, top+(y+1)*cell, p)
        p.textAlign = Paint.Align.CENTER; p.textSize = size*.075f; p.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText("PATHBACK START", size/2f, size*.94f, p)
        return b
    }
}
