package org.pathback.app

import android.content.Context
import android.os.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class Feedback(context: Context) : TextToSpeech.OnInitListener {
    private val tts = TextToSpeech(context, this)
    private val vibrator = context.getSystemService(Vibrator::class.java)
    private var ready = false
    override fun onInit(status: Int) { ready = status == TextToSpeech.SUCCESS; if (ready) tts.language = Locale.getDefault() }
    fun speak(text: String, interrupt: Boolean = false) {
        if (ready) tts.speak(text, if (interrupt) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, text)
    }
    fun pulse(count: Int) {
        val timings = mutableListOf<Long>(0)
        repeat(count) { timings += 120; timings += 100 }
        vibrator.vibrate(VibrationEffect.createWaveform(timings.toLongArray(), -1))
    }
    fun close() { tts.stop(); tts.shutdown() }
}
