package org.pathback.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.ar.core.exceptions.*
import java.text.DateFormat
import java.util.*

enum class Screen { HOME, RECORD, ROUTE }

class MainActivity : ComponentActivity() {
    private lateinit var feedback: Feedback
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); feedback = Feedback(this)
        setContent { PathBackApp(feedback) }
    }
    override fun onDestroy() { feedback.close(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun PathBackApp(feedback: Feedback) {
    val context = LocalContext.current
    val store = remember { RouteStore(context) }
    var routes by remember { mutableStateOf(store.load()) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var selected by remember { mutableStateOf<SavedRoute?>(null) }
    var guidanceReverse by remember { mutableStateOf(false) }
    var cameraGranted by remember { mutableStateOf(context.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { cameraGranted = it }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF003B73))) {
        Scaffold(topBar = { TopAppBar(title = { Text("PathBack", fontSize = 26.sp) }, navigationIcon = {
            if (screen != Screen.HOME) TextButton(onClick = { screen = Screen.HOME }) { Text("Back") }
        }) }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (screen) {
                    Screen.HOME -> Home(routes, feedback, onRecord = {
                        if (!cameraGranted) permission.launch(Manifest.permission.CAMERA) else screen = Screen.RECORD
                    }, onRoute = { selected = it; screen = Screen.ROUTE })
                    Screen.RECORD -> if (cameraGranted) Recorder(feedback) { route ->
                        routes = routes + route; store.save(routes); selected = route; screen = Screen.ROUTE
                    } else PermissionMessage { permission.launch(Manifest.permission.CAMERA) }
                    Screen.ROUTE -> selected?.let { route -> RouteDetails(route, onGuide = { reverse ->
                        guidanceReverse = reverse; screen = Screen.ROUTE
                    }, guiding = guidanceReverse, feedback = feedback, cameraGranted = cameraGranted,
                        onDelete = { routes = routes - route; store.save(routes); screen = Screen.HOME }) }
                }
            }
        }
    }
}

@Composable private fun Home(routes: List<SavedRoute>, feedback: Feedback, onRecord: () -> Unit, onRoute: (SavedRoute) -> Unit) {
    var speechEnabled by remember { mutableStateOf(feedback.speechEnabled) }
    val context = LocalContext.current
    val capabilities = remember { PositioningCapabilities.detect(context) }
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("Indoor route guidance", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.semantics { heading() }) }
        item { Text("Record a path, then receive spoken and vibration guidance in either direction.", fontSize = 18.sp) }
        item { BigButton("Record a new route", "Starts the camera-based indoor route recorder", action = onRecord) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Spoken guidance", fontSize = 18.sp)
            Switch(checked = speechEnabled, onCheckedChange = { speechEnabled = it; feedback.speechEnabled = it },
                modifier = Modifier.semantics { stateDescription = if (speechEnabled) "On" else "Off" })
        } }
        item { Text("Saved routes", style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() }) }
        if (routes.isEmpty()) item { Text("No routes saved", fontSize = 18.sp) }
        items(routes) { r -> OutlinedButton(onClick = { onRoute(r) }, modifier = Modifier.fillMaxWidth().heightIn(min = 64.dp)) {
            Column { Text(r.name, fontSize = 20.sp); Text(DateFormat.getDateTimeInstance().format(Date(r.created))) }
        } }
        item { Text("Positioning providers", style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() }) }
        items(capabilities) { capability ->
            Text("${capability.name}: ${if (capability.available) "Available" else "Not configured or unavailable"}. ${capability.detail}.", fontSize = 16.sp)
        }
        item { Text("Safety: Use your cane or guide dog. PathBack does not detect traffic, stairs, drop-offs, or all obstacles.", fontSize = 16.sp) }
    }
}

@Composable private fun PermissionMessage(request: () -> Unit) = Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
    Text("Camera permission is required for motion tracking. PathBack does not save pictures or video.", fontSize = 20.sp)
    BigButton("Allow camera", "Opens the Android camera permission request", action = request)
}

@Composable private fun Recorder(feedback: Feedback, onSaved: (SavedRoute) -> Unit) {
    val context = LocalContext.current
    var latest by remember { mutableStateOf<Point3?>(null) }; var tracking by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }; val points = remember { mutableStateListOf<Point3>() }
    var returning by remember { mutableStateOf(false) }; var returnIndex by remember { mutableIntStateOf(0) }
    var returnStatus by remember { mutableStateOf("Preparing return guidance") }; var lastReturnSpeech by remember { mutableLongStateOf(0) }
    val landmarks = remember { mutableStateListOf<Landmark>() }; var showSave by remember { mutableStateOf(false) }
    var routeName by remember { mutableStateOf("") }; var landmarkName by remember { mutableStateOf("") }
    var landmarkKind by remember { mutableStateOf("Note") }; var showLandmark by remember { mutableStateOf(false) }; var showLandmarkType by remember { mutableStateOf(false) }
    var capturingVisual by remember { mutableStateOf(false) }; var visualReady by remember { mutableStateOf(false) }
    var visualObservation by remember { mutableStateOf<VisualObservation?>(null) }
    val visualKeyframes = remember { mutableStateListOf<VisualKeyframe>() }
    var previousTracking by remember { mutableStateOf(false) }; var latestYaw by remember { mutableFloatStateOf(0f) }
    val tracker = remember { ArTracker(context, { point, y, ok -> latest = point; latestYaw = y; tracking = ok }, { visualObservation = it }) }
    DisposableEffect(Unit) { runCatching { tracker.resume(context) }.onFailure { feedback.speak(arError(it), true) }; onDispose { tracker.pause(); tracker.close() } }
    LaunchedEffect(latest, recording) {
        val p = latest ?: return@LaunchedEffect
        if (tracking && !previousTracking) feedback.speak("Tracking ready", true)
        if (!tracking && previousTracking) { feedback.speak("Tracking limited. Hold the phone upright and move slowly.", true); feedback.pulse(3) }
        previousTracking = tracking
        if (recording && tracking && (points.isEmpty() || Navigator.distance(points.last(), p) >= .35f)) points += p
        if (returning && tracking) {
            val reverse = points.asReversed()
            val g = Navigator.guidance(p, latestYaw, reverse, returnIndex) ?: return@LaunchedEffect
            returnIndex = g.pointIndex
            returnStatus = if (g.offRoute) "Off route. Move toward ${g.clock} o'clock." else "${g.meters.toInt().coerceAtLeast(1)} meters, ${g.clock} o'clock"
            val now = System.currentTimeMillis()
            if (now-lastReturnSpeech > 4000) {
                feedback.speak(returnStatus, true)
                feedback.pulse(if (g.offRoute) 3 else if (g.clock in 11..12 || g.clock == 1) 1 else 2)
                lastReturnSpeech = now
            }
            if (returnIndex >= reverse.lastIndex-3 && g.meters < 1.2f) {
                returning = false; returnStatus = "You have returned to the starting point"
                feedback.speak(returnStatus, true); feedback.pulse(3)
            }
        }
    }
    LaunchedEffect(visualObservation, capturingVisual) {
        val observation = visualObservation ?: return@LaunchedEffect
        if (!capturingVisual) return@LaunchedEffect
        val sufficientlyDifferent = visualKeyframes.none { java.lang.Long.bitCount(it.hash xor observation.hash) < 7 }
        if (sufficientlyDifferent) {
            visualKeyframes += VisualKeyframe(observation.hash, observation.point, observation.yaw)
            feedback.speak("Visual view ${visualKeyframes.size} of 8 captured")
        }
        if (visualKeyframes.size >= 8) {
            capturingVisual = false; visualReady = true
            feedback.speak("Visual area anchor ready. Return the phone to your forward travel direction.", true); feedback.pulse(3)
        }
    }
    Box(Modifier.fillMaxSize()) {
        AndroidView({ tracker.view }, Modifier.fillMaxSize().clearAndSetSemantics { })
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(if (tracking) "Tracking ready" else "Move the phone slowly until tracking is ready", fontSize = 22.sp,
                modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
            Text(if (returning) returnStatus else if (recording) "Recording. ${points.size} trail points." else if (capturingVisual) "Creating visual anchor. Slowly turn in place. ${visualKeyframes.size} of 8 views captured." else if (visualReady) "Visual area anchor ready." else "Choose a physical anchor or create a visual-area anchor for an open space.", fontSize = 18.sp,
                modifier = Modifier.semantics { if (returning) liveRegion = LiveRegionMode.Polite })
            if (capturingVisual) {
                BigButton("Cancel visual anchor", "Stops capturing the open-area visual anchor") {
                    capturingVisual = false; visualReady = false; visualKeyframes.clear()
                }
            } else if (!recording && !returning) {
                BigButton("Use physical anchor and record", "Uses the phone's current position and direction as a repeatable physical anchor", enabled = tracking) {
                    if (tracker.alignHere()) { recording = true; visualReady = false; visualKeyframes.clear(); feedback.speak("Physical anchor set. Recording started", true); feedback.pulse(1) }
                }
                if (!visualReady) BigButton("Create visual-area anchor", "Captures local visual fingerprints while you slowly turn in an open area", enabled = tracking) {
                    if (tracker.alignHere()) { visualKeyframes.clear(); capturingVisual = true; feedback.speak("Slowly turn in place to capture the surrounding area", true) }
                }
                else BigButton("Start recording with visual anchor", "Begins recording from the completed visual-area anchor", enabled = tracking) {
                    recording = true; feedback.speak("Recording started", true); feedback.pulse(1)
                }
            } else if (recording) {
                BigButton("Add landmark", "Adds a typed and named place at your current position") { landmarkName = ""; showLandmarkType = true }
                BigButton("Guide me back now", "Stops recording and immediately retraces the current path", enabled = points.size > 3) {
                    recording = false; returning = true; returnIndex = 0; feedback.speak("Immediate return guidance started", true)
                }
                BigButton("Finish and save", "Stops recording and asks for a route name", enabled = points.size > 3) { recording = false; showSave = true; feedback.speak("Recording stopped", true) }
            } else if (returning) {
                BigButton("Repeat return instruction", "Repeats the current return instruction") { feedback.speak(returnStatus, true) }
                BigButton("Stop return guidance", "Ends immediate return guidance") { returning = false }
            }
        }
    }
    if (showLandmarkType) LandmarkTypeDialog({ showLandmarkType = false }) { kind ->
        landmarkKind = kind; showLandmarkType = false; showLandmark = true
    }
    if (showLandmark) NameDialog("$landmarkKind landmark name", landmarkName, { landmarkName = it }, { showLandmark = false }, {
        if (landmarkName.isNotBlank()) { landmarks += Landmark(landmarkName.trim(), points.lastIndex.coerceAtLeast(0), landmarkKind); feedback.speak("$landmarkKind landmark ${landmarkName.trim()} added") }; showLandmark = false
    })
    if (showSave) NameDialog("Route name", routeName, { routeName = it }, { showSave = false }, {
        if (routeName.isNotBlank()) {
            val savedPoints = points.toList()
            onSaved(SavedRoute(
                id = UUID.randomUUID().toString(), name = routeName.trim(), created = System.currentTimeMillis(),
                points = savedPoints, landmarks = landmarks.toList(), endYaw = latestYaw,
                checkpoints = Navigator.checkpoints(savedPoints),
                anchorConfidence = if (visualKeyframes.size >= 8) .85f else if (tracking && savedPoints.size >= 10) 1f else .6f,
                startVisualKeyframes = visualKeyframes.toList()
            ))
        }
    })
}

@Composable private fun RouteDetails(route: SavedRoute, onGuide: (Boolean) -> Unit, guiding: Boolean, feedback: Feedback, cameraGranted: Boolean, onDelete: () -> Unit) {
    var mode by remember(route.id) { mutableStateOf<Boolean?>(null) }
    if (mode != null && cameraGranted) { Guide(route, mode == true, feedback) { mode = null }; return }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(route.name, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.semantics { heading() })
        val feet = (Navigator.length(route.points) * 3.28084f).toInt()
        val quality = when { route.anchorConfidence >= .85f -> "Strong"; route.anchorConfidence >= .6f -> "Fair"; else -> "Low" }
        val vertical = route.landmarks.count { it.kind in setOf("Stairs", "Elevator", "Ramp", "Escalator") }
        Text("Route preview: approximately $feet feet, ${Navigator.turnCount(route.points)} turns, $vertical vertical transitions, ${route.landmarks.size} landmarks, and ${route.checkpoints.size} recovery checkpoints.", fontSize = 18.sp)
        Text("Anchor confidence: $quality.", fontSize = 18.sp,
            modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
        BigButton("Guide forward", "Guides from the original start to the destination") { mode = false; onGuide(false) }
        BigButton("Guide back", "Guides from the destination back to the original start") { mode = true; onGuide(true) }
        route.landmarks.forEach { Text("${it.kind} landmark: ${it.name}", fontSize = 18.sp) }
        OutlinedButton(onClick = onDelete, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("Delete route") }
    }
}

@Composable private fun Guide(route: SavedRoute, reverse: Boolean, feedback: Feedback, stop: () -> Unit) {
    val context = LocalContext.current
    val points = remember(route.id, reverse) { if (reverse) Navigator.reverseFromDestination(route.points, route.endYaw) else route.points }
    var position by remember { mutableStateOf<Point3?>(null) }; var yaw by remember { mutableFloatStateOf(0f) }; var tracking by remember { mutableStateOf(false) }
    var index by remember { mutableIntStateOf(0) }; var lastSpeech by remember { mutableLongStateOf(0) }; var status by remember { mutableStateOf("Finding your position…") }
    var aligned by remember { mutableStateOf(false) }
    var visualObservation by remember { mutableStateOf<VisualObservation?>(null) }
    var visualDistance by remember { mutableIntStateOf(64) }
    var verticalPaused by remember { mutableStateOf(false) }
    val announcedLandmarks = remember { mutableStateListOf<Int>() }
    val tracker = remember { ArTracker(context, { p, y, ok -> position = p; yaw = y; tracking = ok }, { visualObservation = it }) }
    DisposableEffect(Unit) { runCatching { tracker.resume(context) }.onFailure { feedback.speak(arError(it), true) }; onDispose { tracker.pause(); tracker.close() } }
    LaunchedEffect(visualObservation, aligned) {
        if (aligned || reverse || route.startVisualKeyframes.isEmpty()) return@LaunchedEffect
        val observation = visualObservation ?: return@LaunchedEffect
        val match = Navigator.visualMatch(observation.hash, route.startVisualKeyframes)
        if (match != null) {
            visualDistance = match.second
            if (tracker.alignTo(match.first.point, match.first.yaw)) {
                aligned = true; status = "Visual anchor recognized. Guidance starting."
                feedback.speak(status, true); feedback.pulse(3)
            }
        }
    }
    LaunchedEffect(position) {
        val p = position ?: return@LaunchedEffect
        if (!aligned) { status = "Align with the route anchor before starting"; return@LaunchedEffect }
        if (!tracking) { status = "Tracking limited"; return@LaunchedEffect }
        val g = Navigator.guidance(p, yaw, points, index) ?: return@LaunchedEffect; index = g.pointIndex
        val originalIndex = if (reverse) route.points.lastIndex-g.pointIndex else g.pointIndex
        route.landmarks.forEachIndexed { landmarkNumber, landmark ->
            if (landmarkNumber !in announcedLandmarks && kotlin.math.abs(landmark.pointIndex-originalIndex) <= 2) {
                announcedLandmarks += landmarkNumber
                val notice = "Approaching ${landmark.kind.lowercase()}: ${landmark.name}."
                feedback.speak(notice, true); feedback.pulse(3)
                if (landmark.kind == "Elevator") { verticalPaused = true; status = "$notice Guidance paused while using the elevator." }
            }
        }
        if (verticalPaused) return@LaunchedEffect
        val exact = index >= points.lastIndex-8 || g.meters < 3f
        status = when {
            g.offRoute -> "Off route. Move toward ${g.clock} o'clock."
            exact -> "Final approach. ${String.format(Locale.getDefault(), "%.1f", g.meters)} meters, ${g.clock} o'clock"
            else -> "${g.meters.toInt().coerceAtLeast(1)} meters, ${g.clock} o'clock"
        }
        val now = System.currentTimeMillis()
        val interval = if (exact) 1500 else 4000
        if (now-lastSpeech > interval) { feedback.speak(status, true); feedback.pulse(if (g.offRoute) 3 else if (g.clock in 11..12 || g.clock == 1) 1 else 2); lastSpeech = now }
        if (index >= points.lastIndex-3 && g.meters < .75f) { feedback.speak("You have arrived at the exact destination area", true); feedback.pulse(3); stop() }
    }
    Box(Modifier.fillMaxSize()) {
        AndroidView({ tracker.view }, Modifier.fillMaxSize().clearAndSetSemantics { })
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text("Guiding ${if (reverse) "back" else "forward"}", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.semantics { heading() })
            Text(status, fontSize = 24.sp, modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
            Text("Keep the phone upright. Continue using your cane or guide dog.", fontSize = 18.sp)
            if (!aligned && !reverse && route.startVisualKeyframes.isNotEmpty())
                Text("Slowly turn and point the camera around the starting area. Visual matching happens on this phone.", fontSize = 18.sp)
            if (!aligned) BigButton("Align with anchor", "Sets the current physical phone position and direction as the route anchor", enabled = tracking) {
                if (tracker.alignHere()) { aligned = true; status = "Anchor aligned. Guidance starting."; feedback.speak(status, true); feedback.pulse(2) }
            }
            if (verticalPaused) BigButton("Resume after elevator", "Resumes route guidance after leaving the elevator") {
                verticalPaused = false; status = "Guidance resumed"; feedback.speak(status, true)
            }
            BigButton("Repeat instruction", "Repeats the current navigation instruction") { feedback.speak(status, true) }
            BigButton("Stop guidance", "Ends navigation") { stop() }
        }
    }
}

@Composable private fun LandmarkTypeDialog(cancel: () -> Unit, select: (String) -> Unit) {
    val types = listOf("Note", "Door", "Stairs", "Elevator", "Ramp", "Escalator", "Seat", "Hazard warning")
    AlertDialog(
        onDismissRequest = cancel,
        title = { Text("Choose landmark type") },
        text = { LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(types) { type -> OutlinedButton(onClick = { select(type) }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text(type) } }
        } },
        confirmButton = {},
        dismissButton = { TextButton(onClick = cancel) { Text("Cancel") } }
    )
}

@Composable private fun BigButton(text: String, description: String, enabled: Boolean = true, action: () -> Unit) {
    Button(onClick = action, enabled = enabled, modifier = Modifier.fillMaxWidth().heightIn(min = 68.dp).semantics { contentDescription = "$text. $description" }) { Text(text, fontSize = 20.sp) }
}

@Composable private fun NameDialog(title: String, value: String, change: (String) -> Unit, cancel: () -> Unit, save: () -> Unit) {
    AlertDialog(onDismissRequest = cancel, title = { Text(title) }, text = { OutlinedTextField(value, change, label = { Text(title) }, singleLine = true) },
        confirmButton = { TextButton(onClick = save, enabled = value.isNotBlank()) { Text("Save") } }, dismissButton = { TextButton(onClick = cancel) { Text("Cancel") } })
}

private fun arError(t: Throwable) = when (t) {
    is UnavailableArcoreNotInstalledException -> "Google Play Services for A R must be installed."
    is UnavailableApkTooOldException -> "Google Play Services for A R must be updated."
    is UnavailableDeviceNotCompatibleException -> "This phone does not support A R motion tracking."
    is CameraNotAvailableException -> "The camera is being used by another app."
    else -> "Motion tracking could not start. ${t.message ?: ""}"
}
