package org.pathback.app

import org.junit.Assert.*
import org.junit.Test

class NavigatorTest {
    private fun p(x: Float, z: Float) = Point3(x, 0f, z, 0)
    @Test fun straightAheadIsTwelve() {
        val g = Navigator.guidance(p(0f, 0f), 0f, listOf(p(0f, 0f), p(0f, -1f), p(0f, -2f), p(0f, -3f)), 0)
        assertEquals(12, g?.clock)
    }
    @Test fun pointToRightIsThree() {
        val g = Navigator.guidance(p(0f, 0f), 0f, listOf(p(0f, 0f), p(1f, 0f), p(2f, 0f), p(3f, 0f)), 0)
        assertEquals(3, g?.clock)
    }
    @Test fun distantPositionIsOffRoute() {
        val g = Navigator.guidance(p(10f, 10f), 0f, listOf(p(0f, 0f), p(0f, -1f), p(0f, -2f), p(0f, -3f)), 0)
        assertTrue(g?.offRoute == true)
    }

    @Test fun reverseRouteStartsAtNewOrigin() {
        val original = listOf(p(0f, 0f), p(0f, -2f), p(0f, -4f))
        val reverse = Navigator.reverseFromDestination(original, 0f)
        assertEquals(0f, reverse.first().x, .001f)
        assertEquals(0f, reverse.first().z, .001f)
        assertEquals(4f, reverse.last().z, .001f)
    }

    @Test fun checkpointsIncludeBothEndpoints() {
        val route = (0..30).map { p(0f, -it.toFloat()) }
        val checkpoints = Navigator.checkpoints(route)
        assertEquals(0, checkpoints.first().pointIndex)
        assertEquals(route.lastIndex, checkpoints.last().pointIndex)
        assertTrue(checkpoints.size > 2)
    }
}
