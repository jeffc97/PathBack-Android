package org.pathback.app

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import com.google.ar.core.Config
import com.google.ar.core.Pose
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import java.util.concurrent.atomic.AtomicReference
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class ArTracker(context: Context, private val onPose: (Point3, Float, Boolean) -> Unit) : GLSurfaceView.Renderer {
    val view = GLSurfaceView(context).apply {
        setEGLContextClientVersion(2); setRenderer(this@ArTracker)
        renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
    }
    private val sessionRef = AtomicReference<Session?>()
    private val cameraPoseRef = AtomicReference<Pose?>()
    private val originRef = AtomicReference<Pose?>()
    private var texture = 0

    fun resume(context: Context) {
        if (sessionRef.get() == null) {
            val session = Session(context)
            session.configure(Config(session).apply { focusMode = Config.FocusMode.AUTO })
            sessionRef.set(session)
        }
        sessionRef.get()?.resume(); view.onResume()
    }

    fun alignHere(): Boolean {
        val pose = cameraPoseRef.get() ?: return false
        val forward = pose.zAxis
        val yaw = atan2(-forward[0], -forward[2]); val half = yaw / 2f
        originRef.set(Pose.makeTranslation(pose.tx(), pose.ty(), pose.tz())
            .compose(Pose.makeRotation(0f, sin(half), 0f, cos(half))))
        return true
    }

    fun isAligned() = originRef.get() != null
    fun pause() { view.onPause(); sessionRef.get()?.pause() }
    fun close() { sessionRef.getAndSet(null)?.close() }
    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        val textures = IntArray(1); GLES20.glGenTextures(1, textures, 0); texture = textures[0]
        sessionRef.get()?.setCameraTextureName(texture)
        GLES20.glClearColor(0.97f, 0.97f, 0.97f, 1f)
    }
    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) { GLES20.glViewport(0, 0, width, height) }
    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        val session = sessionRef.get() ?: return
        if (texture != 0) session.setCameraTextureName(texture)
        runCatching {
            val camera = session.update().camera; cameraPoseRef.set(camera.pose)
            val pose = originRef.get()?.inverse()?.compose(camera.pose) ?: camera.pose
            val forward = pose.zAxis; val yaw = atan2(-forward[0], -forward[2])
            onPose(Point3(pose.tx(), pose.ty(), pose.tz(), System.currentTimeMillis()), yaw,
                camera.trackingState == TrackingState.TRACKING)
        }
    }
}
