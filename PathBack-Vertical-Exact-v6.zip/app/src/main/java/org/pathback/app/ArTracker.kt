package org.pathback.app

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import com.google.ar.core.Config
import com.google.ar.core.Pose
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import android.media.Image
import java.util.concurrent.atomic.AtomicReference
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

data class VisualObservation(val hash: Long, val point: Point3, val yaw: Float)

class ArTracker(
    context: Context,
    private val onPose: (Point3, Float, Boolean) -> Unit,
    private val onVisual: (VisualObservation) -> Unit = {}
) : GLSurfaceView.Renderer {
    val view = GLSurfaceView(context).apply {
        setEGLContextClientVersion(2); setRenderer(this@ArTracker)
        renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
    }
    private val sessionRef = AtomicReference<Session?>()
    private val cameraPoseRef = AtomicReference<Pose?>()
    private val originRef = AtomicReference<Pose?>()
    private var texture = 0
    private var lastVisualAt = 0L

    fun resume(context: Context) {
        if (sessionRef.get() == null) {
            val session = Session(context)
            session.configure(Config(session).apply { focusMode = Config.FocusMode.AUTO })
            sessionRef.set(session)
        }
        sessionRef.get()?.resume(); view.onResume()
    }

    fun alignHere(): Boolean {
        val pose = cameraPoseRef.get() ?: return false
        val forward = pose.zAxis
        val yaw = atan2(-forward[0], -forward[2]); val half = yaw / 2f
        originRef.set(Pose.makeTranslation(pose.tx(), pose.ty(), pose.tz())
            .compose(Pose.makeRotation(0f, sin(half), 0f, cos(half))))
        return true
    }

    fun alignTo(savedPoint: Point3, savedYaw: Float): Boolean {
        val current = cameraPoseRef.get() ?: return false
        val half = savedYaw / 2f
        val saved = Pose.makeTranslation(savedPoint.x, savedPoint.y, savedPoint.z)
            .compose(Pose.makeRotation(0f, sin(half), 0f, cos(half)))
        originRef.set(current.compose(saved.inverse()))
        return true
    }

    fun isAligned() = originRef.get() != null
    fun pause() { view.onPause(); sessionRef.get()?.pause() }
    fun close() { sessionRef.getAndSet(null)?.close() }
    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        val textures = IntArray(1); GLES20.glGenTextures(1, textures, 0); texture = textures[0]
        sessionRef.get()?.setCameraTextureName(texture)
        GLES20.glClearColor(0.97f, 0.97f, 0.97f, 1f)
    }
    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) { GLES20.glViewport(0, 0, width, height) }
    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        val session = sessionRef.get() ?: return
        if (texture != 0) session.setCameraTextureName(texture)
        runCatching {
            val frame = session.update(); val camera = frame.camera; cameraPoseRef.set(camera.pose)
            val pose = originRef.get()?.inverse()?.compose(camera.pose) ?: camera.pose
            val forward = pose.zAxis; val yaw = atan2(-forward[0], -forward[2])
            onPose(Point3(pose.tx(), pose.ty(), pose.tz(), System.currentTimeMillis()), yaw,
                camera.trackingState == TrackingState.TRACKING)
            val now = System.currentTimeMillis()
            if (camera.trackingState == TrackingState.TRACKING && now-lastVisualAt >= 750) {
                runCatching { frame.acquireCameraImage() }.getOrNull()?.use { image ->
                    VisualHasher.differenceHash(image)?.let { hash ->
                        onVisual(VisualObservation(hash, Point3(pose.tx(), pose.ty(), pose.tz(), now), yaw))
                    }
                }
                lastVisualAt = now
            }
        }
    }
}

object VisualHasher {
    /** 64-bit difference hash computed from the Y plane; no image bytes are retained. */
    fun differenceHash(image: Image): Long? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer; val rowStride = plane.rowStride; val pixelStride = plane.pixelStride
        if (image.width < 18 || image.height < 16) return null
        val values = IntArray(72); var n = 0
        for (y in 0 until 8) {
            val sy = ((y + .5f) * image.height / 8f).toInt().coerceIn(0, image.height-1)
            for (x in 0 until 9) {
                val sx = ((x + .5f) * image.width / 9f).toInt().coerceIn(0, image.width-1)
                val offset = sy * rowStride + sx * pixelStride
                if (offset >= buffer.limit()) return null
                values[n++] = buffer.get(offset).toInt() and 0xff
            }
        }
        var hash = 0L; var bit = 0
        for (y in 0 until 8) for (x in 0 until 8) {
            if (values[y*9+x] > values[y*9+x+1]) hash = hash or (1L shl bit)
            bit++
        }
        return hash
    }
}
