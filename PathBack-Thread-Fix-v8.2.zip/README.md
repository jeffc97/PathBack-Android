# PathBack for Android

PathBack is an original, accessibility-first alpha indoor route recorder inspired by the
general purpose of Clew. It records a trail using ARCore motion tracking and guides
the user along that trail in either direction.

## Open and build

1. Open this folder in Android Studio.
2. Allow Android Studio to install the requested Android SDK and sync Gradle.
3. Connect an ARCore-supported Android phone (the Pixel 9 is supported).
4. Build and run the `app` configuration.

The app requests camera permission because ARCore uses the camera to estimate the
phone's movement. Route data stays on the phone. No images or video are saved.

## Accessible use

Hold the phone upright with the rear camera unobstructed. From the home screen,
activate **Record a new route**. Wait for “Tracking ready,” place the phone in a
repeatable position if saving the route, then activate **Set start anchor and record**.
Walk normally. Add named landmarks if desired. At the destination,
activate **Finish and save**, enter a route name, and save it. Choose the route and
select **Guide forward** or **Guide back**.

Guidance announces clock directions and distance. A short vibration means continue;
two pulses mean turn; three pulses indicate that tracking is limited or the user is
off the recorded path.

## Important safety limits

This is an orientation aid, not a mobility aid. It does not detect drop-offs,
traffic, stairs, doors, or every obstacle. Continue using a cane or guide dog and
your normal travel skills. ARCore tracking can drift, especially in darkness,
featureless hallways, reflective spaces, or when the camera is covered.

## Offline physical alignment

PathBack uses a repeatable phone pose to establish a route coordinate system without
a printed marker. For the strongest saved-route anchor, place the phone's top edge
against the same fixed wall, doorway, or counter when recording and when reloading.
For an immediate return, the active AR session can retrace the route without reloading
an anchor. Route processing occurs on the phone; no image or video is uploaded. This
release remains an engineering preview until tested in the specific buildings where
it will be used.

For an open area, choose **Create visual-area anchor** and slowly turn in place. The
app retains eight small 64-bit grayscale fingerprints with their AR poses. It does not
retain camera frames. When the route is reopened, slowly scan the starting area until
the app recognizes a saved view. Changed lighting, furniture, or viewing angles can
prevent recognition; use physical alignment as the fallback.

Typed landmarks identify doors, stairs, elevators, ramps, escalators, seats, notes,
and hazard warnings. Elevator landmarks pause ordinary guidance until the user
confirms they have exited. Near a destination, exact-destination mode automatically
uses decimal distances and more frequent feedback. Landmark notices provide context;
they never certify that stairs, doors, or hazards are safe.
