package org.pathback.app

import kotlinx.serialization.Serializable
import kotlin.math.*

@Serializable data class Point3(val x: Float, val y: Float, val z: Float, val time: Long)
@Serializable data class Landmark(val name: String, val pointIndex: Int, val kind: String = "Note")
@Serializable data class RecoveryCheckpoint(val pointIndex: Int, val reason: String, val confidence: Float = 1f)
@Serializable data class VisualKeyframe(val hash: Long, val point: Point3, val yaw: Float)
@Serializable data class CloudAnchorInfo(
    val id: String,
    val hostedAt: Long,
    val expiresAt: Long,
    val consentVersion: Int = 1
)
@Serializable data class GeoPoint(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float,
    val time: Long
)
@Serializable data class SavedRoute(
    val id: String, val name: String, val created: Long,
    val points: List<Point3>, val landmarks: List<Landmark> = emptyList(),
    val endYaw: Float = 0f,
    val checkpoints: List<RecoveryCheckpoint> = emptyList(),
    val anchorConfidence: Float = 1f,
    val lastVerified: Long? = null,
    val startVisualKeyframes: List<VisualKeyframe> = emptyList(),
    val startCloudAnchor: CloudAnchorInfo? = null,
    val startGeoAnchor: GeoPoint? = null
)

data class Guidance(val pointIndex: Int, val meters: Float, val clock: Int, val offRoute: Boolean)

object Navigator {
    fun distance(a: Point3, b: Point3) = sqrt((a.x-b.x).pow(2)+(a.y-b.y).pow(2)+(a.z-b.z).pow(2))
    fun guidance(position: Point3, yaw: Float, points: List<Point3>, from: Int): Guidance? {
        if (points.isEmpty()) return null
        val lo = (from - 8).coerceAtLeast(0)
        val hi = (from + 20).coerceAtMost(points.lastIndex)
        val nearest = (lo..hi).minByOrNull { distance(position, points[it]) } ?: return null
        val target = (nearest + 3).coerceAtMost(points.lastIndex)
        val p = points[target]
        val dx = p.x-position.x; val dz = p.z-position.z
        val bearing = atan2(dx, -dz)
        var relative = Math.toDegrees((bearing-yaw).toDouble()).toFloat()
        while (relative < -180) relative += 360
        while (relative > 180) relative -= 360
        val clock = ((relative / 30f).roundToInt() + 12).let { if (it <= 0) it+12 else if (it>12) it-12 else it }
        return Guidance(nearest, distance(position, p), clock, distance(position, points[nearest]) > 2.5f)
    }

    fun reverseFromDestination(points: List<Point3>, endYaw: Float): List<Point3> {
        if (points.isEmpty()) return points
        val end = points.last(); val c = cos(-endYaw); val s = sin(-endYaw)
        return points.asReversed().map { p ->
            val dx = p.x - end.x; val dz = p.z - end.z
            Point3(c * dx - s * dz, p.y - end.y, s * dx + c * dz, p.time)
        }
    }

    fun length(points: List<Point3>): Float = points.zipWithNext()
        .sumOf { (a, b) -> distance(a, b).toDouble() }.toFloat()

    fun checkpoints(points: List<Point3>): List<RecoveryCheckpoint> {
        if (points.size < 3) return emptyList()
        val result = mutableListOf(RecoveryCheckpoint(0, "Route start"))
        var last = 0
        for (i in 1 until points.lastIndex) {
            val a = points[i-1]; val b = points[i]; val c = points[i+1]
            val h1 = atan2(b.x-a.x, -(b.z-a.z)); val h2 = atan2(c.x-b.x, -(c.z-b.z))
            var turn = abs(Math.toDegrees((h2-h1).toDouble()).toFloat())
            if (turn > 180) turn = 360-turn
            if (turn >= 35f || distance(points[last], b) >= 5f) {
                result += RecoveryCheckpoint(i, if (turn >= 35f) "Turn" else "Distance checkpoint")
                last = i
            }
        }
        result += RecoveryCheckpoint(points.lastIndex, "Destination")
        return result.distinctBy { it.pointIndex }
    }

    fun turnCount(points: List<Point3>): Int = checkpoints(points).count { it.reason == "Turn" }

    fun visualMatch(hash: Long, keyframes: List<VisualKeyframe>): Pair<VisualKeyframe, Int>? = keyframes
        .map { it to java.lang.Long.bitCount(it.hash xor hash) }
        .minByOrNull { it.second }
        ?.takeIf { it.second <= 10 }
}
