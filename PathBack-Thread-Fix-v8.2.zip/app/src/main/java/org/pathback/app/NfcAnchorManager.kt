package org.pathback.app

import android.app.Activity
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.nfc.tech.NdefFormatable

sealed interface NfcAnchorEvent {
    data class RouteRead(val routeId: String) : NfcAnchorEvent
    data class Status(val message: String, val success: Boolean) : NfcAnchorEvent
}

class NfcAnchorManager(private val activity: Activity) : NfcAdapter.ReaderCallback {
    private val adapter: NfcAdapter? = NfcAdapter.getDefaultAdapter(activity)
    @Volatile private var routeToWrite: String? = null
    @Volatile private var listener: ((NfcAnchorEvent) -> Unit)? = null

    val available: Boolean get() = adapter != null

    fun setListener(value: ((NfcAnchorEvent) -> Unit)?) { listener = value }

    fun resume() {
        adapter?.enableReaderMode(
            activity,
            this,
            NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V or
                NfcAdapter.FLAG_READER_NFC_BARCODE,
            null
        )
    }

    fun pause() { adapter?.disableReaderMode(activity) }

    fun prepareRouteTag(routeId: String) {
        routeToWrite = routeId
        emit(NfcAnchorEvent.Status("Ready. Hold an unlocked N F C tag against the phone.", true))
    }

    fun cancelWrite() { routeToWrite = null }

    override fun onTagDiscovered(tag: Tag) {
        val pending = routeToWrite
        if (pending != null) write(tag, pending) else read(tag)
    }

    private fun write(tag: Tag, routeId: String) {
        val message = NdefMessage(arrayOf(NdefRecord.createUri("pathback://route/$routeId")))
        val result = runCatching {
            val ndef = Ndef.get(tag)
            if (ndef != null) {
                ndef.connect()
                try {
                    require(ndef.isWritable) { "This N F C tag is locked or read-only" }
                    require(ndef.maxSize >= message.toByteArray().size) { "This N F C tag is too small" }
                    ndef.writeNdefMessage(message)
                } finally { ndef.close() }
            } else {
                val formatable = NdefFormatable.get(tag) ?: error("This tag cannot store an N F C route anchor")
                formatable.connect()
                try { formatable.format(message) } finally { formatable.close() }
            }
        }
        if (result.isSuccess) {
            routeToWrite = null
            emit(NfcAnchorEvent.Status("N F C route anchor written successfully", true))
        } else emit(NfcAnchorEvent.Status(result.exceptionOrNull()?.message ?: "Could not write the N F C tag", false))
    }

    private fun read(tag: Tag) {
        val result = runCatching {
            val ndef = Ndef.get(tag) ?: error("This tag does not contain a PathBack route")
            ndef.connect()
            val message = try { ndef.ndefMessage ?: ndef.cachedNdefMessage } finally { ndef.close() }
            val uri = message?.records?.asSequence()?.mapNotNull { it.toUri() }
                ?.firstOrNull { it.scheme == "pathback" && it.host == "route" }
                ?: error("This is not a PathBack route tag")
            uri.lastPathSegment ?: error("The PathBack route identifier is missing")
        }
        result.onSuccess { emit(NfcAnchorEvent.RouteRead(it)) }
            .onFailure { emit(NfcAnchorEvent.Status(it.message ?: "Could not read the N F C tag", false)) }
    }

    private fun emit(event: NfcAnchorEvent) = activity.runOnUiThread { listener?.invoke(event) }
}
