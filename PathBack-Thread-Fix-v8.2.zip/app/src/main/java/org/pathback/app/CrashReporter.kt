package org.pathback.app

import android.content.Context
import java.io.File

object CrashReporter {
    private const val FILE_NAME = "last-crash.txt"

    fun install(context: Context) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                val summary = buildString {
                    append(error.javaClass.simpleName)
                    error.message?.takeIf { it.isNotBlank() }?.let { append(": ").append(it.take(300)) }
                    error.stackTrace.take(4).forEach { append("\n").append(it.className).append(".").append(it.methodName).append(":").append(it.lineNumber) }
                }
                File(context.filesDir, FILE_NAME).writeText(summary)
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun consume(context: Context): String? {
        val file = File(context.filesDir, FILE_NAME)
        return runCatching { if (file.exists()) file.readText().also { file.delete() } else null }.getOrNull()
    }
}
