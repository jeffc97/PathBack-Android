package org.pathback.app

import android.content.Context
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

class RouteStore(context: Context) {
    private val file = File(context.filesDir, "routes.json")
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }
    fun load(): List<SavedRoute> = runCatching { json.decodeFromString<List<SavedRoute>>(file.readText()) }.getOrDefault(emptyList())
    fun save(routes: List<SavedRoute>) = file.writeText(json.encodeToString(routes))
}

