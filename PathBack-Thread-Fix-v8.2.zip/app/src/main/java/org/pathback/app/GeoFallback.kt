package org.pathback.app

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import kotlin.math.*

object GeoFallback {
    @SuppressLint("MissingPermission")
    fun current(context: Context, callback: (GeoPoint?) -> Unit) {
        val manager = context.getSystemService(LocationManager::class.java)
        if (manager == null || Build.VERSION.SDK_INT < 30 || !manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            callback(null); return
        }
        runCatching {
            manager.getCurrentLocation(LocationManager.GPS_PROVIDER, CancellationSignal(), context.mainExecutor) { location ->
                callback(location?.toGeoPoint())
            }
        }.onFailure { callback(null) }
    }

    fun distanceMeters(a: GeoPoint, b: GeoPoint): Float {
        val earth = 6_371_000.0
        val lat1 = Math.toRadians(a.latitude); val lat2 = Math.toRadians(b.latitude)
        val dLat = lat2-lat1; val dLon = Math.toRadians(b.longitude-a.longitude)
        val h = sin(dLat/2).pow(2) + cos(lat1)*cos(lat2)*sin(dLon/2).pow(2)
        return (2*earth*asin(sqrt(h))).toFloat()
    }

    private fun Location.toGeoPoint() = GeoPoint(latitude, longitude, accuracy, time)
}
