package org.pathback.app

import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build

data class ProviderCapability(val name: String, val available: Boolean, val detail: String)

object PositioningCapabilities {
    fun detect(context: Context): List<ProviderCapability> {
        val pm = context.packageManager
        val location = context.getSystemService(LocationManager::class.java)
        return listOf(
            ProviderCapability("AR motion tracking", pm.hasSystemFeature("android.hardware.camera.ar"),
                "Primary indoor route tracking on ARCore-compatible phones"),
            ProviderCapability("Physical anchors", true, "Offline repeatable phone pose"),
            ProviderCapability("Local visual anchors", true, "On-device visual fingerprints"),
            ProviderCapability("Outdoor GPS", location?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true,
                "General outdoor area; not exact final positioning"),
            ProviderCapability("NFC landmarks", pm.hasSystemFeature(PackageManager.FEATURE_NFC),
                "Optional tap-to-identify route or location"),
            ProviderCapability("Wi-Fi RTT", pm.hasSystemFeature(PackageManager.FEATURE_WIFI_RTT),
                "Requires compatible building access points"),
            ProviderCapability("Ultra-wideband", Build.VERSION.SDK_INT >= 31 && pm.hasSystemFeature("android.hardware.uwb"),
                "Requires a compatible nearby anchor accessory"),
            ProviderCapability("Cloud visual anchors", pm.hasSystemFeature("android.hardware.camera.ar"),
                "Configured for optional persistent recognition with local fallback")
        )
    }
}
